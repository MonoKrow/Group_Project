﻿using UnityEngine;

public class GoalScript : MonoBehaviour
{
    void Start()
    {
        
    }
}
